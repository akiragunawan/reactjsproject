import React from 'react'

function Topbar() {
    function toggle_btn(e) {
        e.preventDefault();
        var sibars = document.getElementById("sidebar")
        var btn_sibar = document.getElementById('sidebarCollapse')
        sibars.classList.toggle("active")
        btn_sibar.classList.toggle("active")
    }
    return (<div>


        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">

                <button type="button" id="sidebarCollapse" onClick={toggle_btn} class="navbar-btn">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <svg viewBox="0 0 100 80" width="20" height="20">
                        <rect width="50" height="20"></rect>
                        <rect y="30" width="100" height="20"></rect>
                        <rect y="60" width="80" height="20"></rect>
                    </svg>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#">Page</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Page</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Page</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Page</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


    </div>)
}
export default Topbar;