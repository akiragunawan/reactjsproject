import React, { useState } from 'react'
import '../../css/LoginForm.css'

import { Link } from 'react-router-dom';

function LoginForm({ Login, error }) {
    const [Datas, setDatas] = useState({ email: "", password: "" })
    const [Registerr, setRegister] = useState(false);



    const submitHandler = e => {
        e.preventDefault();

        Login(Datas);
    }

    return (
        <div>
            {/* {(!Registerr) ? ( */}
            <div className='back-color'>

                <form onSubmit={submitHandler} className='position-absolute top-50 start-50 translate-middle second-back-color w-75 p-4 p-sm-4 p-md-4 p-lg-5 p-xl-5' >
                    <span className="float-end fw-bold text-white">LOGIN</span>
                    <h1 className="fw-bolder font-monospace">PORCA<br /><span className="fw-normal fs-3 text-white">Mission Control</span></h1>
                    <hr className="w-50" style={{ height: '3px', backgroundColor: 'white', opacity: '1' }} />
                    {(error != "") ? (<div className="text-danger">{error}</div>) : ""}
                    <div className="mb-3">
                        <label htmlFor="email" className="form-label" >Email address</label>
                        <input onChange={e => setDatas({ ...Datas, email: e.target.value })} value={Datas.email} type="email" id="email" name="email" className="form-control" />
                        <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="password" className="form-label">Password</label>
                        <input onChange={e => setDatas({ ...Datas, password: e.target.value })} value={Datas.password} type="password" id="password" name="password" className="form-control" />
                    </div>
                    <div className="mb-3 form-check">



                        <Link to="/Register" className='text-decoration-none float-start float-sm-end float-md-end float-lg-end float-xl-end floar-xxl-end text-dark pt-2 pb-2'>

                            Create New Account Here

                        </Link>


                    </div>
                    <input type="submit" className="btn btn-outline-dark d-block w-100" value="Login" />
                </form>
            </div>
            {/* // ) : (
            //         <RegisterForm Register={handleRegister} />
        //     )
        // } */}

        </div >
    )
}

export default LoginForm
