import React, { useState } from 'react'
import '../../css/Register.css'
import Swal from 'sweetalert2'
import withReactContent from 'sweetalert2-react-content'
import { useHistory  } from 'react-router-dom'


function InformationForm({ Email, Client }) {
    const [userData, setUserData] = useState({ username: "", phone: "", password: ""});
    const [conpassError, setConPassError] = useState();
    const [usernameError,setUsernameError] = useState();
    const [phoneError, sePhoneError] = useState();
    const[ready,setReady] = useState({validation1:false,validation2:false});
    const [saveReady, setSaveReady] = useState(false);
    const MySwal = withReactContent(Swal)
    
    let history = useHistory();

    Client.onmessage = msg =>{
        let req = JSON.parse(msg.data);
        let timerInterval;
        if ("event" in req && "payload" in req) {
                         
            switch (req.event){
                case "REGISTER_STATUS":
                    switch (req.payload.status){
                        case "success" :
                        

                            MySwal.fire({
                                icon: 'success',
                                title: 'Registration Complete',
                                text: "Re-directing you to Login Page",
                                showConfirmButton: false,
                                timer : 1500,
                                timerProgressBar: true,
                            }).then(() =>{
                                
                                return history.push('/')
                            })
                            break;
                        case "failed":
                            MySwal.fire({
                                icon: 'Failed',
                                title: 'Registration Failed',
                                text: "Try to refresh the page",
                                showConfirmButton: false,
                                timer: 5000,
                                timerProgressBar: true,
                            })
                            break;
                    }
                break;

                case "REGISTER_USERNAME" :
                    switch (req.payload.code){
                        case "success" :
                            setUsernameError(false);
                            setReady({ ...ready, validation1: true })
                        break;
                        case "failed":
                            setUsernameError(true);
                        break;
                    }
                break;

                case "REGISTER_PHONE" :
                    switch (req.payload.code){
                        case "success":
                            sePhoneError(false);
                            setReady({ ...ready, validation2: true })
                        break;
                        case "failed" :
                            sePhoneError(true);
                        break;
                    }
                break;
            }
     
        } 
    }

    if (ready.validation1 && ready.validation2){
        setReady({ ...ready, validation1: false, validation2: false })
        setSaveReady(true)
    }


    const HandleSaveData = (e) => {
        e.preventDefault();
        setSaveReady(false)

        if(conpassError){
            Client.send(JSON.stringify({
                event: "CHECKING_REGISTER_DATA",
                payload: {
                    username : userData.username,
                    phone : userData.phone
                }
            }))

            if (saveReady) {
                
                Client.send(JSON.stringify({
                    event: "REGISTERING_DATA",
                    payload: {
                        username: userData.username,
                        phone: userData.phone,
                        password: userData.password,
                        email: Email
                    }
                }))
            }else{
                console.log('error Saving')
            }
        }

        // Client.onmessage = msg => {
        //     let req = JSON.parse(msg.data);
        //     if ("event" in req && "payload" in req) {
        //         if (req.event === "REGISTER_STATUS") {
        //             if (req.payload.status === "success") {
        //                 console.log("successsssssss");

        //                 // MySwal.fire({
        //                 //     title: <p>Register Complete!</p>,
        //                 //     footer: 'Copyright 2020'

        //                 // })
        //             } else if (req.payload.status === "failed") {
        //                 console.log("failed");
        //             }
        //         }
        //     }
        // }

    

      
    }

    return (
        <div className='back-color'>

            <form onClick={HandleSaveData} className='position-absolute top-50 start-50 translate-middle second-back-color w-75 p-4 p-sm-4 p-md-4 p-lg-5 p-xl-5' >
                <span className="float-end fw-bold text-white">REGISTER</span>
                <h1 className="fw-bolder font-monospace">PORCA<br /><span className="fw-normal fs-3 text-white">Mission Control</span></h1>
                <hr className="w-50" style={{ height: '3px', backgroundColor: 'white', opacity: '1' }} />

                <div className="mb-3">
                    <h3 className="text-white text-uppercase text-center">Informations</h3>
                    <div className="pt-3">
                        <label htmlFor="username" className="form-label" >Username</label>
                        <input id="username" type="text" className="form-control ml-2 mr-2" autofocus="" placeholder="Enter Your Username"
                            onChange={e => setUserData({ ...userData, username: e.target.value })}
                            value={userData.username} />
                    </div>
                    {(usernameError) ? (<div className="text-danger">Username Already Exists</div>) : ""}
                    <div className="pt-3">
                        <label htmlFor="email" className="form-label" >Email</label>
                        <input id="email" type="email" className="form-control ml-2 mr-2" autofocus="" value={Email} disabled />
                    </div>
                    <div className="pt-3">
                        <label htmlFor="phone" className="form-label" >Phone Number</label>
                        <input id="phone" type="text" className="form-control ml-2 mr-2" autofocus="" placeholder="Enter Your Phone Number (eg: 8521222222)"
                            onChange={e => setUserData({ ...userData, phone: e.target.value })}
                            value={userData.phone} />
                    </div>
                     {(phoneError) ? (<div className="text-danger">Phone Number Already Exists</div>) : ""}

                    <div className="pt-3">
                        <label htmlFor="password" className="form-label" >Password</label>
                        <input id="password" type="password" className="form-control ml-2 mr-2" autofocus="" placeholder="Enter Your Password"
                            onChange={e => setUserData({ ...userData, password: e.target.value })}
                            value={userData.password} />
                    </div>
                    <div className="pt-3">
                        <label htmlFor="conpass" className="form-label" >Confirm Password</label>
                        <input id="conpass" type="password" className="form-control ml-2 mr-2" autofocus="" placeholder="Enter Your Password again"
                            onChange={
                                e => (userData.password == e.target.value) ? setConPassError(true) : setConPassError(false)}
                           
                             />
                    </div>
                    {(conpassError) ?  "" : (<div className="text-danger">Password Doesn't Match</div>)}




                </div>


                <input type="submit" className="btn btn-outline-dark d-block w-100" value="Next" />

            </form>
        </div >
    )
}

export default InformationForm
