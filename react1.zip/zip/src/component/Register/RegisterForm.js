import React, { useState } from 'react'
import '../../css/Register.css'
import OTPForm from '../../component/Register/OTPForm'
import { Link } from 'react-router-dom';


function RegisterForm({ Client }) {
    const [Email, setEmail] = useState("");
    const [isEmail, setIsEmail] = useState(false);
    const [err, setErr] = useState("")
    const [code, setCode] = useState("");
    const [sendAgainCode, setSendAgainCode] = useState(false)
    const [sendAgainCodeClick, setSendAgainCodeClick] = useState(false)

    var timeLeft = 5;
    var timer;

    const HandleBackLogin = e => {
        e.preventDefault();

    }


    const countdown = () => {
        if (timeLeft == -1) {
            clearTimeout(timer);
            setSendAgainCode(true);
        } else {
            setSendAgainCode(false);
            console.log(timeLeft);
            timeLeft--;
        }
    }


    const handleisEmail = e => {

        e.preventDefault();

        setSendAgainCode(false);

        if (Email) {

            Client.send(JSON.stringify({
                event: "SENDING_EMAIL",
                payload: {
                    email: Email,
                    stat: ""
                }
            }))
            console.log("Success Sending Email to Server");

        } else {
            setIsEmail(false);
            setErr("Invalid Email or already exist")
        }
    }
    Client.onmessage = (msg) => {

        let req = JSON.parse(msg.data);
        if ("event" in req && "payload" in req) {
            if (req.event == "EMAIL_CHECK") {


                if (req.payload.status === "success") {

                    Client.send(JSON.stringify({
                        event: "SENDING_OTP",
                        payload: {
                            email: Email,
                            stat: ""
                        }
                    }))
                } else if (req.payload.status == "failed") {
                    setErr("Email ALready Exists")
                }
            }

        } else {
            console.log("err")
        }

        if (req.event == "OTP_CODE") {
            console.log(req.payload.code)
            if (req.payload.code != "Failed") {
                setCode(req.payload.code);
                timer = setInterval(countdown, 1000);
                setIsEmail(true)
            } else {
                setCode("");
                setErr("Error Recieving OTP code, Try to Re-Launch the Application");
            }
        } else if (req.event == "OTP_CODE_EXPIRE") {
            setCode("")
            console.log("expire")
        }


    }



    if (sendAgainCodeClick) {
        setSendAgainCodeClick(false)

        timeLeft = 5
        timer = setInterval(countdown, 1000);

        Client.send(JSON.stringify({
            event: "SENDING_OTP",
            payload: {
                email: Email,
                stat: "resend"
            }
        }))


    }

    return (
        <div>
            {(isEmail) ? (
                <OTPForm Email={Email} Code={code} Client={Client} sendAgainCode={sendAgainCode} setSendAgainCode={setSendAgainCode} setSendAgainCodeClick={setSendAgainCodeClick} />
            ) : (
                    <div className='back-color'>

                        <form onSubmit={handleisEmail} className='position-absolute top-50 start-50 translate-middle second-back-color w-75 p-4 p-sm-4 p-md-4 p-lg-5 p-xl-5' >
                            <span className="float-end fw-bold text-white">REGISTER</span>
                            <h1 className="fw-bolder font-monospace">PORCA<br /><span className="fw-normal fs-3 text-white">Mission Control</span></h1>
                            <hr className="w-50" style={{ height: '3px', backgroundColor: 'white', opacity: '1' }} />
                            {(err != "") ? (<div className="text-danger">{err}</div>) : ""}
                            <div className="mb-3">
                                <label htmlFor="email" className="form-label" >Email address</label>
                                <input type="email" id="email" name="email" className="form-control" onChange={e => setEmail(e.target.value)} value={Email} />
                                <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
                            </div>



                            <input type="submit" className="btn btn-outline-dark d-block w-100" value="Next" />
                            <div >
                                <Link to="/" className='text-decoration-none text-dark d-flex justify-content-center mt-3'>
                                    Login Here
                                </Link>
                            </div>
                        </form>
                    </div >
                )
            }


        </div >
    )
}

export default RegisterForm
