import React, { useState } from 'react'
import '../../css/Register.css'
import InformationForm from '../../component/Register/InformationForm'

function OTPForm({ Email, Code, Client, sendAgainCode, setSendAgainCode, setSendAgainCodeClick }) {
    const [otp, setOtp] = useState()
    const [isSuccess, setIsSuccess] = useState(false)
    const HandleSendCode = e => {
        e.preventDefault();
        setSendAgainCodeClick(true);
    }

    const handleOTP = e => {
        e.preventDefault();
        if (otp) {
            if (otp == Code) {
                console.log("success");
                setIsSuccess(true)
                Client.send(JSON.stringify({
                    event: "OTP_SUCCESS",
                    payload: {
                        code: ""
                    }
                }))
                setSendAgainCode(false)
            } else {
                console.log("Wrong OTP Code")
            }
        }
    }

    return (
        <div>
            {(isSuccess) ? (
                <InformationForm Email={Email} Client={Client} />
            ) : (
                    <div className='back-color'>

                        <form onSubmit={handleOTP} className='position-absolute top-50 start-50 translate-middle second-back-color w-75 p-4 p-sm-4 p-md-4 p-lg-5 p-xl-5' >
                            <span className="float-end fw-bold text-white">REGISTER</span >
                            <h1 className="fw-bolder font-monospace">PORCA<br /><span className="fw-normal fs-3 text-white">Mission Control</span></h1>
                            <hr className="w-50" style={{ height: '3px', backgroundColor: 'white', opacity: '1' }} />
                            {/* {(err != "") ? (<div className="text-danger">{err}</div>) : ""} */}
                            <div className="mb-3">
                                <label htmlFor="email" className="form-label" >OTP Code</label>
                                <p className="text-black-50">Check Your Email we send you a four digit Code to <span className="text-dark">{Email}</span> </p>
                                <div className="  ">
                                    <input type="text" className="form-control ml-2 mr-2 text-center" autofocus="" onChange={e => setOtp(e.target.value)} value={otp} />

                                </div>
                                {(sendAgainCode) ? (<a href="#" onClick={HandleSendCode} className="text-decoration-none text-dark d-flex justify-content-center mt-3">Send Code Again</a>) : ""}

                            </div>


                            <input type="submit" className="btn btn-outline-dark d-block w-100" value="Next" />

                        </form >
                    </div >
                )}
        </div>


    )
}



export default OTPForm

