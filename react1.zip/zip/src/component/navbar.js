import React, { useState } from 'react';
import '../css/sidebar.css'
import { Link } from 'react-router-dom';


function Navbar({ Logout }) {

    const HandleLogout = e => {
        e.preventDefault();
        Logout(true)
    }


    return (
        <div>


            <nav id="sidebar">
                <div className="sidebar-header">
                    <h5 className="fw-bolder">PORCA<br></br><span className="fw-normal text-dark">Mission Control</span></h5>
                </div>

                <ul className="list-unstyled components ">
                    <li >
                        <a href="#" className=" w-100 text-dark text-decoration-none ">Dashboard</a>
                    </li>
                    <li className="active">
                        <div className="btn-group dropend w-100 ">
                            <a className="dropdown-toggle w-100 text-dark text-decoration-none" data-bs-toggle="dropdown" aria-expanded="false">
                                Component
                                </a>
                            <ul class="dropdown-menu m-1">
                                <a href="" className="dropdown-item">
                                    Component Library
                                    </a>
                                <a href="" className="dropdown-item">
                                    Component Category
                                    </a>
                                <a href="" className="dropdown-item">
                                    Formulas
                                    </a>
                            </ul>

                        </div>

                    </li>
                    <li className="active">
                        <div className="btn-group dropend w-100 ">
                            <a className="dropdown-toggle w-100 text-dark text-decoration-none" data-bs-toggle="dropdown" aria-expanded="false">
                                Stock
                                </a>
                            <ul class="dropdown-menu m-1">
                                <a href="" className="dropdown-item">
                                    Summary
                                    </a>
                                <a href="" className="dropdown-item">
                                    Transfer
                                    </a>
                                <a href="" className="dropdown-item">
                                    Adjustment
                                    </a>
                            </ul>

                        </div>

                    </li>
                    <li className="active">
                        <div className="btn-group dropend w-100 ">
                            <a className="dropdown-toggle w-100 text-dark text-decoration-none" data-bs-toggle="dropdown" aria-expanded="false">
                                Member
                                </a>
                            <ul class="dropdown-menu m-1">
                                <a href="" className="dropdown-item">
                                    Member List
                                    </a>
                                <a href="" className="dropdown-item">
                                    Loyality Program
                                    </a>
                                <a href="" className="dropdown-item">
                                    Feedback
                                    </a>

                            </ul>

                        </div>

                    </li>
                    <li className="active">
                        <div className="btn-group dropend w-100 ">
                            <a className="dropdown-toggle w-100 text-dark text-decoration-none" data-bs-toggle="dropdown" aria-expanded="false">
                                Employees
                                </a>
                            <ul class="dropdown-menu m-1">
                                <a href="" className="dropdown-item">
                                    Employees List
                                    </a>
                                <a href="" className="dropdown-item">
                                    Employees Permissions
                                    </a>



                            </ul>

                        </div>

                    </li>
                    <li>
                        <div className="btn-group dropend w-100 ">
                            <a className="dropdown-toggle w-100 text-dark text-decoration-none" data-bs-toggle="dropdown" aria-expanded="false">
                                items
                                </a>
                            <ul class="dropdown-menu m-1">
                                <Link to="/item_library" className="dropdown-item">
                                    items Library
                                    </Link>
                                <a href="" className="dropdown-item">
                                    Categories
                                    </a>
                                <a href="" className="dropdown-item">
                                    Promo
                                    </a>
                                <a href="" className="dropdown-item">
                                    discount
                                    </a>
                                <a href="" className="dropdown-item">
                                    taxes
                                    </a>
                            </ul>

                        </div>
                    </li>
                    <li>
                        <a href="#" className=" w-100 text-dark text-decoration-none">Payment</a>
                    </li>
                    <li>
                        <a href="#" className=" w-100 text-dark text-decoration-none">Contact</a>
                    </li>
                    <li>
                        <a href="" className=" w-100 text-dark text-decoration-none" onClick={HandleLogout}>Logout</a>
                    </li>
                </ul>


            </nav>







        </div>

    )
}
export default Navbar;