import React, { useState } from 'react';
import Navbar from './component/navbar'
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import "../node_modules/bootstrap/dist/js/bootstrap.min.js"
import './css/sidebar.css'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Dashboard from './component/Dashboard'
import Item_library from './component/Library_list'
import Topbar from './component/Topbar'
import LoginForm from './component/Login/LoginForm'
import RegisterForm from "./component/Register/RegisterForm";

import { w3cwebsocket as websocket } from 'websocket'



function App() {

  const [uid, setUid] = useState("");
  const [isLoggin, setIsLoggin] = useState(false);
  const [showError, setShowError] = useState(false)
  const [error, setError] = useState("");
  const [isLogout, setIsLogout] = useState(false);




  var db;
  var request = indexedDB.open("user", 1)

  request.onsuccess = function (event) {
    db = request.result;
    console.log("creating Database")
    db.transaction("user_id").objectStore("user_id").openCursor().onsuccess = function (event) {
      var cursor = event.target.result;
      if (cursor) {
        setIsLoggin(true)
      } else {
        setIsLoggin(false)


      }
    }
  }
  request.onupgradeneeded = function (event) {
    var db = event.target.result;
    db.createObjectStore("user_id", {
      keyPath: "id"
    });
  }



  //const client = new websocket('wss://www.zerolabind.com/wsporca')
  const client = new websocket('ws://localhost:8000')
  var WS_CONNECT = false;
  client.onopen = () => {
    console.log('Websocket Open');

    WS_CONNECT = true;



  }
  client.onclose = () => {
    console.log("connection close")
    WS_CONNECT = false
  }

  const handleLogout = e => {
    console.log(e)
    if (e == true) {

      setIsLoggin(false)
      db.transaction(["user_id"], "readwrite").objectStore("user_id").delete(0).onsuccess = function (event) {
        console.log("data deleted")
      }
    }
  }


  const Login = Details => {
    if (WS_CONNECT) {


      client.send(JSON.stringify({
        event: "LOGIN_CHECK",
        payload: {
          email: Details.email,
          password: Details.password
        }

      }));
      client.onmessage = (msg) => {
        let req = JSON.parse(msg.data);
        if ("event" in req && "payload" in req) {
          if (req.event == "LOGIN_RESULT") {
            if (req.payload.status == "success") {
              setUid(req.payload.uid)
              setIsLoggin(true);
              setError("");

              db.transaction(["user_id"], "readwrite").objectStore("user_id").add({
                id: 0,
                uid: req.payload.uid
              })

            } else {
              setUid(req.payload.uid)
              setIsLoggin(false);
              setError("Email or Password doesn't match or didin't exist");
            }
          }
        }
      }


    }

  }



  return (

    <div>
      <Router>
        {(isLoggin) ? (

          <div className='wrapper'>

            <Navbar Logout={handleLogout} ></Navbar>
            <div id='content'>
              <Topbar></Topbar>

              <Switch>
                <Route path="/" exact component={Dashboard} />
                <Route path="/item_library" exact component={Item_library} />


              </Switch>

            </div>

          </div>

        ) : (
            <div>

              <Switch>
                <Route path="/" exact >
                  <LoginForm Login={Login} error={error} />
                </Route>

                <Route path="/Register" exact >
                  <RegisterForm Client={client} />
                </Route>
              </Switch>
            </div>
          )}

      </Router>

    </div>

  );
}

export default App;
