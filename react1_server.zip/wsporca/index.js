require('dotenv').config()
const webSocket = require('ws');
const mysql = require('mysql');
const wss = new webSocket.Server({ port: 8000 });
const nodemailer = require('nodemailer');

var con = mysql.createConnection({
  host: "localhost",
  user: "Tlms",
  password: "source21",
  database: "porca"
});
let transporter = nodemailer.createTransport({

  host: "mail.zerolabind.com",
  port: 465,
  secure: true, // use TLS
  auth: {
    user: process.env.EMAIL,
    pass: process.env.PASSWORD
  }
});
var email = "";
var txt = "";

var mailOptions = {
  from: "auth@zerolabind.com",
  to: email,
  subject: "Message title",
  text: "Plaintext version of the message",
  html: `<p>${txt}</p>`
};


wss.on('connection', function connection(ws) {
  console.log("new Connection ")
  let data;
  var timer;
  try {


    ws.on('message', function (message) {
      data = JSON.parse(message);

      var email = data.payload.email;
      var pass = data.payload.password;
      if ("event" in data) {
        switch (data.event) {
          case "LOGIN_CHECK":

            con.query("SELECT * FROM user where email = ? and password = ?", [email, pass], function (err, result, fields) {
              if (result != 0) {
                ws.send(JSON.stringify({
                  event: "LOGIN_RESULT",
                  payload: {
                    status: "success",
                    uid: result[0].uid
                  }
                }))


              } else {
                ws.send(JSON.stringify({
                  event: "LOGIN_RESULT",
                  payload: {
                    status: "failed",
                    uid: ""
                  }
                }))

              }
            });


            break;
          case "SENDING_EMAIL":
            email = data.payload.email;
            con.query("SELECT * FROM user where email =?", [email], function (err, result, fields) {
              console.log(result)
              if (result.length == 0) {
                ws.send(JSON.stringify({
                  event: "EMAIL_CHECK",
                  payload: {
                    status: "success"

                  }
                }))
              } else {
                console.log("Email Exist")
                ws.send(JSON.stringify({
                  event: "EMAIL_CHECK",
                  payload: {
                    status: "failed",

                  }
                }))
              }
            })
            break;

          case "SENDING_OTP":
            var timeLeft = 300;
            email = data.payload.email;
            console.log(email)
            const countdown = () => {
              if (timeLeft == -1) {
                clearTimeout(timer);
                txt = ""

                ws.send(JSON.stringify({
                  event: "OTP_CODE_EXPIRE",
                  payload: {
                    code: txt,
                  }
                }))
              } else {
                console.log(timeLeft)
                timeLeft--;
              }
            }

            console.log(data.payload.stat)
            switch (data.payload.stat) {
              case "resend":
                clearTimeout(timer)
                txt = Math.floor(1000 + Math.random() * 9000);
                ws.send(JSON.stringify({
                  event: "OTP_CODE",
                  payload: {
                    code: txt,
                  }
                }))
                break;

              case "":
                console.log("not re-sending")
                txt = Math.floor(1000 + Math.random() * 9000);
                ws.send(JSON.stringify({
                  event: "OTP_CODE",
                  payload: {
                    code: txt,
                  }
                }))
            }
            console.log(txt)
            mailOptions = {
              from: "auth@zerolabind.com",
              to: email,
              subject: "Message title",
              text: "Plaintext version of the message",
              html: `<p>${txt}</p>`
            };

            if (email != "" && txt != "") {
              clearTimeout(timer);
              timer = setInterval(countdown, 1000);

              transporter.sendMail(mailOptions, function (err, data) {
                if (err) {
                  console.log(err)
                } else {
                  console.log("success sending email to Provider")

                }
              })
            } else {
              console.log("Reciever Empty")
              ws.send(JSON.stringify({
                event: "OTP_CODE",
                payload: {
                  code: "Failed",
                }
              }))
            }

            break;




          case "OTP_SUCCESS":
            clearTimeout(timer);
            break;
          case "OTP_RESEND":
            clearTimeout(timer);
            break;
          case "CHECKING_REGISTER_DATA":
            var username = data.payload.username;
            var phone = data.payload.phone;


            con.query("SELECT * FROM user where username =?", [username], function (err, result, fields) {

              if (result != 0) {

                ws.send(JSON.stringify({
                  event: "REGISTER_USERNAME",
                  payload: {
                    code: "failed",
                  }
                }))
              } else {
                ws.send(JSON.stringify({
                  event: "REGISTER_USERNAME",
                  payload: {
                    code: "success",
                  }
                }))
              }

            })
            con.query("SELECT * FROM user where phone_number =?", [phone], function (err, result, fields) {

              if (result != 0) {

                ws.send(JSON.stringify({
                  event: "REGISTER_PHONE",
                  payload: {
                    code: "failed",
                  }
                }))
              } else {
                ws.send(JSON.stringify({
                  event: "REGISTER_PHONE",
                  payload: {
                    code: "success",
                  }
                }))
              }

            })


            break;
          case "REGISTERING_DATA":

            function GetDate() {
              var todayTime = new Date();
              var month = todayTime.getMonth() + 1;
              var day = todayTime.getDate();
              var year = todayTime.getFullYear();
              return year + "-" + month + "-" + day;
            }


            var username_register = data.payload.username
            var phone_register = data.payload.phone
            var date = GetDate()
            var email_register = data.payload.email
            var password_register = data.payload.password
            var uid_generator = (Math.random() + ' ').substring(2, 10) + (Math.random() + ' ').substring(2, 10);
            var uid_string = uid_generator.toString()

            if (uid_string.charAt(0) == "0") {
              uid_generator = (Math.random() + ' ').substring(2, 10) + (Math.random() + ' ').substring(2, 10);

            }
            con.query("select * from user where uid =?", [uid_generator], function (err, result, fields) {
              if (result != 0) {
                uid_generator = (Math.random() + ' ').substring(2, 10) + (Math.random() + ' ').substring(2, 10);

              } else {
                con.query("select * from user where email =?", [email_register], function (err, result, fields) {

                  if (result != 0) {

                  } else {
                    con.query("insert into user (user.uid,user.username,user.password,user.email,user.date_join,user.phone_number) Values (?,?,?,?,?,?)",
                      [uid_generator, username_register, password_register, email_register, date, phone_register],
                      function (err, result, fields) {

                        if (!result) {

                          ws.send(JSON.stringify({
                            event: "REGISTER_STATUS",
                            payload: {
                              status: "failed",
                              errorMsg: err
                            }
                          }))
                          console.log("fail saving")

                        } else {


                          ws.send(JSON.stringify({
                            event: "REGISTER_STATUS",
                            payload: {
                              status: "success"
                            }
                          }))


                        }
                      })
                  }
                })
              }
            })

            break;
        }

      } else {
        throw new Error("Event or Payload Missing")
      }

    });
  } catch (e) {
    console.log(toString(e));
  }




});


